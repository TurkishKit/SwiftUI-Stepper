//
//  ContentView.swift
//  SwiftUI Stepper
//
//  Created by Ufuk Köşker on 25.09.2020.
//

import SwiftUI

struct ContentView: View {
    @State var age = 0
    var body: some View {
        VStack {
            Text("\(age)")
                .padding()
            
//            Stepper(value: $age, in: 0...5) {
//                Text("Yaş:")
//            }
            Stepper("Yaşını Seç:") {
                self.age += 2
            } onDecrement: {
                self.age -= 2
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
